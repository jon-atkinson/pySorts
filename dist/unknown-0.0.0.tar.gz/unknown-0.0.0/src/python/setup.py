#!/usr/bin/env python

from distutils.core import setup

setup(name='pySorts',
      version='0.01',
      description='simple sorts comparison',
      author='Jon Atkinson'
     )